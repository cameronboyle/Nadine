<!-- sidebar -->
<div class="sidebar large-offset-1 large-3 columns">

	<?php if ( is_active_sidebar( 'right_sidebar' ) ) : ?>

		<?php dynamic_sidebar( 'right_sidebar' ); ?>

	<?php endif; ?>
						

</div>
<!-- sidebar -->
