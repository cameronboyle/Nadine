<?php get_header(); ?>

<div class="the-content large-12 columns centered" role="main">

	<h1>Page Not Found!</h1>  
	<p>404's are such a lovely thing. But you know, I'm not going to leave you stranded.</p>

	<?php get_search_form(); ?>
	<a href="<?php echo home_url( '/' ); ?>">&larr; Go Home?</a>

</div>
	
<?php get_footer(); ?>