<form role="search" method="get" class="searchform" action="<?php echo home_url( '/' ); ?>">
	<input type="text" placeholder="SEARCH" name="s" id="s" class="large-8 small-9 columns">
	<button type="submit" class="button large-4 small-3 columns">GO</button>
</form>
<div class="row"></div>